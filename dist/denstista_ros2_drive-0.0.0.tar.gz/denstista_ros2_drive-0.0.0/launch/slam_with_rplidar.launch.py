from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os
from launch.actions import ExecuteProcess

def generate_launch_description():
    my_package_share_dir = get_package_share_directory('denstista_ros2_drive')
    slam_config_path = os.path.join(my_package_share_dir, 'config', 'slam_config.yaml')
    script_path = os.path.join(my_package_share_dir, 'scripts','create_map_dir.sh')

    return LaunchDescription([
        ExecuteProcess(
            cmd=[script_path],
            shell=True,
            output='screen'
        ),
        Node(
            package=my_package_share_dir,
            executable='odom_publisher',
            name='odom_publisher',
            output='screen'
        ),

        Node(
            package='rplidar_ros',
            executable='rplidar_composition',
            name='rplidar',
            output='screen',
            parameters=[{'frame_id': 'laser'}]
        ),

        Node(
            package='slam_toolbox',
            executable='sync_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[slam_config_path, {'use_sim_time': False, 'use_odometry': True}],
            remappings=[('scan', '/scan')]
        ),

        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            arguments=['0.2', '0', '0.15', '0', '0', '0', 'base_link', 'laser'],
        )
    ])
